package Assignment;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.*;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
public class GoogleSearchAutomation {
	public static void main(String[] args) throws IOException {
		// Define the column indexes (0-based index)
		// Column C (Search Terms)
		int searchColumn = 2;
		// Column D (Longest Suggestion)
		int longestColumn = 3;
		// Column E (Shortest Suggestion)
		int shortestColumn = 4;
		System.out.println(" Shortest Suggestion Completed");
		// Get current day of the week
		String today = LocalDate.now().getDayOfWeek().toString().toLowerCase();
		// Convert to "Monday", "Tuesday", etc.
		today = today.substring(0, 1).toUpperCase() + today.substring(1);
		System.out.println("Convert to everyday Completed");
		// Load Excel file
		// Ensure this file exists
		String excelFilePath = "C:\\Users\\Mehedi Hasan\\Downloads\\Excel.xlsx";
		FileInputStream fis = new FileInputStream(excelFilePath);
		Workbook workbook = new XSSFWorkbook(fis);
		System.out.println("Excel file here exists Completed");
		// Get the sheet for today's day
		Sheet sheet = workbook.getSheet(today);
		if (sheet == null) {
			System.out.println("No sheet found for " + today);
			workbook.close();
			fis.close();
			return;
		}
		System.out.println("Today sheet run Completed");
		// Setup WebDriver
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.out.println("Setup WebDriver and Implicitywait");
		// Iterate over rows (skip header row)
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			Row row = sheet.getRow(i);
			if (row == null)
				continue;
			Cell searchCell = row.getCell(searchColumn);
			if (searchCell == null || searchCell.getCellType() != CellType.STRING)
				continue;
			String searchQuery = searchCell.getStringCellValue();
			driver.get("https://www.google.com/");
			System.out.println("Url setup Completed");
			// Enter search term in Google Search
			WebElement searchBox = driver.findElement(By.xpath("//*[@id=\"APjFqb\"]"));
			searchBox.sendKeys(searchQuery);
			System.out.println("searchbox xpath setup");
			// Wait for search suggestions to appear
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			List<WebElement> suggestions = wait
					.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//*[@id=\"Alh6id\"]/div[1]")));
			System.out.println("Wait for search suggestions to appear");
			// Find longest and shortest suggestions
			String longestSuggestion = "", shortestSuggestion = suggestions.get(0).getText();
			for (WebElement suggestion : suggestions) {
				String text = suggestion.getText();
				if (text.length() > longestSuggestion.length()) {
					longestSuggestion = text;
				}
				if (text.length() <= shortestSuggestion.length()) {
					shortestSuggestion = text;
				}
			}
			System.out.println("Find longest and shortest suggestions");
			// Write results back to Excel in the selected columns
			row.createCell(longestColumn, CellType.STRING).setCellValue(longestSuggestion);
			row.createCell(shortestColumn, CellType.STRING).setCellValue(shortestSuggestion);
		}
		System.out.println("Write results back to Excel in the selected columns");
		// Save changes to Excel
		fis.close();
		FileOutputStream fos = new FileOutputStream(excelFilePath);
		workbook.write(fos);
		fos.close();
		workbook.close();
		System.out.println("Save to Excel");
		// Close browser
		driver.quit();
		System.out.println("Automation completed successfully for " + today);
	}
}

